document.addEventListener('DOMContentLoaded', function () {
    const registerForm = document.querySelector('#registerForm');
    const loginForm = document.querySelector('#loginForm');
    const alertMessage = document.querySelector('#alertMessage');

    if (alertMessage) {
        const searchParams = new URLSearchParams(window.location.search);
        const error = searchParams.get('error');
        const success = searchParams.get('success');
        if (error || success) {
            const alertBox = document.createElement('div');
            alertBox.className = 'alert ' + (error ? 'alert-error' : 'alert-success');
            alertBox.textContent = error || success;
            alertMessage.appendChild(alertBox);
        }
    }

    if (registerForm) {
        registerForm.addEventListener('submit', function (event) {
            const password = registerForm.querySelector('input[name="password"]').value.trim();
            const email = registerForm.querySelector('input[name="email"]').value.trim();

            if (password.length < 6) {
                alert('Password must be at least 6 characters long.');
                event.preventDefault();
                return;
            }

            if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                alert('Please enter a valid email address.');
                event.preventDefault();
            }
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', function (event) {
            const email = loginForm.querySelector('input[name="email"]').value.trim();
            if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                alert('Please enter a valid email address.');
                event.preventDefault();
            }
        });
    }
});
