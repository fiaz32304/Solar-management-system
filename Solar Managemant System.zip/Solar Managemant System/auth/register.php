<?php
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../register.php');
    exit;
}

$fullName = trim($_POST['full_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$phone = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');

if ($fullName === '' || $email === '' || $password === '' || $phone === '' || $address === '') {
    header('Location: ../register.php?error=' . urlencode('All fields are required.'));
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: ../register.php?error=' . urlencode('Enter a valid email address.'));
    exit;
}

if (strlen($password) < 6) {
    header('Location: ../register.php?error=' . urlencode('Password must be at least 6 characters.'));
    exit;
}

$stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = :email');
$stmt->execute(['email' => $email]);
if ($stmt->fetch()) {
    header('Location: ../register.php?error=' . urlencode('Email is already registered.'));
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO users (full_name, email, password, phone, address) VALUES (:full_name, :email, :password, :phone, :address)');
$stmt->execute([
    'full_name' => $fullName,
    'email' => $email,
    'password' => $hashedPassword,
    'phone' => $phone,
    'address' => $address,
]);

header('Location: ../login.php?success=' . urlencode('Registration successful. Please login.'));
exit;
