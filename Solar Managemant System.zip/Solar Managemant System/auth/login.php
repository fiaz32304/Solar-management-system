<?php
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit;
}

$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if ($email === '' || $password === '') {
    header('Location: ../login.php?error=' . urlencode('Email and password are required.'));
    exit;
}

$stmt = $pdo->prepare('SELECT user_id, full_name, password FROM users WHERE email = :email');
$stmt->execute(['email' => $email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    header('Location: ../login.php?error=' . urlencode('Invalid email or password.'));
    exit;
}

session_start();
$_SESSION['user_id'] = $user['user_id'];
$_SESSION['user_name'] = $user['full_name'];

header('Location: ../user/dashboard.php');
exit;
