<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function escape($value) {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function requireUser() {
    if (empty($_SESSION['user_id'])) {
        header('Location: ../login.php');
        exit;
    }
}

function requireAdmin() {
    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }
}

function getStatusClass($status) {
    return match ($status) {
        'Approved' => 'status-approved',
        'Rejected' => 'status-rejected',
        default => 'status-pending',
    };
}
