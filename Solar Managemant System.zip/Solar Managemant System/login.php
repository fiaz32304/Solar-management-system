<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Customer Login - Solar Management</title>
    <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
    <main class="auth-page container">
        <div class="auth-card">
            <h1>Customer Login</h1>
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($_GET['error']); ?></div>
            <?php elseif (isset($_GET['success'])): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
            <?php endif; ?>
            <form id="loginForm" action="auth/login.php" method="POST" novalidate>
                <label>Email</label>
                <input type="email" name="email" required />
                <label>Password</label>
                <input type="password" name="password" required minlength="6" />
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
            <p class="helper-text">New here? <a href="register.php">Register now</a></p>
            <p class="helper-text">Admin user? <a href="admin/index.php">Login here</a></p>
        </div>
    </main>
    <script src="assets/js/script.js"></script>
</body>
</html>
