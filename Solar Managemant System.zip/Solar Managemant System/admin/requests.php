<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = intval($_POST['request_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    $notes = trim($_POST['notes'] ?? '');
    if ($requestId > 0 && in_array($status, ['Pending', 'Approved', 'Rejected'], true)) {
        $stmt = $pdo->prepare('UPDATE requests SET status = :status, notes = :notes WHERE request_id = :request_id');
        $stmt->execute(['status' => $status, 'notes' => $notes, 'request_id' => $requestId]);
    }
    header('Location: requests.php');
    exit;
}

$stmt = $pdo->query('SELECT r.*, u.full_name, u.email, p.name AS product_name FROM requests r JOIN users u ON r.user_id = u.user_id JOIN products p ON r.product_id = p.product_id ORDER BY r.request_date DESC');
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Requests - Admin | Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Admin Panel</h2>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="customers.php">Customers</a>
        <a href="requests.php" class="active">Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Installation Requests</h1>
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>Customer</th>
              <th>Product</th>
              <th>Date</th>
              <th>Status</th>
              <th>Notes</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($requests as $request): ?>
              <tr>
                <td><?php echo escape($request['full_name']); ?><br><small><?php echo escape($request['email']); ?></small></td>
                <td><?php echo escape($request['product_name']); ?></td>
                <td><?php echo escape(date('M j, Y', strtotime($request['request_date']))); ?></td>
                <td><span class="status-pill <?php echo getStatusClass($request['status']); ?>"><?php echo escape($request['status']); ?></span></td>
                <td><?php echo escape($request['notes'] ?: '—'); ?></td>
                <td>
                  <form action="requests.php" method="POST" style="display:grid; gap:0.5rem;">
                    <input type="hidden" name="request_id" value="<?php echo escape($request['request_id']); ?>" />
                    <select name="status">
                      <option value="Pending" <?php echo $request['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                      <option value="Approved" <?php echo $request['status'] === 'Approved' ? 'selected' : ''; ?>>Approved</option>
                      <option value="Rejected" <?php echo $request['status'] === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                    <textarea name="notes" rows="2" placeholder="Optional notes..."><?php echo escape($request['notes']); ?></textarea>
                    <button type="submit" class="btn btn-secondary">Update</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($requests)): ?>
              <tr><td colspan="6">No installation requests yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>
