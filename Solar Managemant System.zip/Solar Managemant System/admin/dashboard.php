<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

$stmt = $pdo->query('SELECT COUNT(*) AS total_users FROM users');
$total_users = $stmt->fetch()['total_users'];
$stmt = $pdo->query('SELECT COUNT(*) AS total_products FROM products');
$total_products = $stmt->fetch()['total_products'];
$stmt = $pdo->query('SELECT COUNT(*) AS total_requests FROM requests');
$total_requests = $stmt->fetch()['total_requests'];
$stmt = $pdo->query("SELECT status, COUNT(*) AS count FROM requests GROUP BY status");
$statusRows = $stmt->fetchAll();
$statusMap = ['Pending' => 0, 'Approved' => 0, 'Rejected' => 0];
foreach ($statusRows as $row) {
    $statusMap[$row['status']] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard - Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Admin Panel</h2>
      <nav>
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="customers.php">Customers</a>
        <a href="requests.php">Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Admin Dashboard</h1>
      <div class="cards-grid">
        <div class="card">
          <h3>Total Customers</h3>
          <p><?php echo escape($total_users); ?></p>
        </div>
        <div class="card">
          <h3>Total Products</h3>
          <p><?php echo escape($total_products); ?></p>
        </div>
        <div class="card">
          <h3>Total Requests</h3>
          <p><?php echo escape($total_requests); ?></p>
        </div>
        <div class="card">
          <h3>Pending Requests</h3>
          <p><?php echo escape($statusMap['Pending']); ?></p>
        </div>
      </div>
      <section style="margin-top: 2rem;">
        <h2>Quick Actions</h2>
        <p>Use the side menu to add products, review installation orders, and manage customers.</p>
      </section>
    </main>
  </div>
</body>
</html>
