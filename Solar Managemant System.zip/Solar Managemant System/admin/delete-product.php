<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();
$productId = intval($_GET['id'] ?? 0);
if ($productId > 0) {
    $stmt = $pdo->prepare('DELETE FROM products WHERE product_id = :product_id');
    $stmt->execute(['product_id' => $productId]);
}
header('Location: products.php');
exit;
