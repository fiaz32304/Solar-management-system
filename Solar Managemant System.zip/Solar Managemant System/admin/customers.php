<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

$stmt = $pdo->query('SELECT * FROM users ORDER BY created_at DESC');
$customers = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Customers - Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Admin Panel</h2>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="customers.php" class="active">Customers</a>
        <a href="requests.php">Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Registered Customers</h1>
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Joined</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($customers as $customer): ?>
              <tr>
                <td><?php echo escape($customer['full_name']); ?></td>
                <td><?php echo escape($customer['email']); ?></td>
                <td><?php echo escape($customer['phone']); ?></td>
                <td><?php echo escape($customer['address']); ?></td>
                <td><?php echo escape(date('M j, Y', strtotime($customer['created_at']))); ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($customers)): ?>
              <tr><td colspan="5">No customers have registered yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>
