<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();
$error = '';
$productId = intval($_GET['id'] ?? 0);
if ($productId <= 0) {
    header('Location: products.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM products WHERE product_id = :product_id');
$stmt->execute(['product_id' => $productId]);
$product = $stmt->fetch();
if (!$product) {
    header('Location: products.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $wattage = trim($_POST['wattage'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $stock = intval($_POST['stock'] ?? 0);

    if ($name === '' || $description === '' || $price === '' || $wattage === '' || $category === '') {
        $error = 'Please complete all fields.';
    } elseif (!is_numeric($price) || floatval($price) < 0) {
        $error = 'Enter a valid price.';
    } else {
        $imagePath = $product['image'];

        if (!empty($_FILES['image']['name'])) {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
            $imageInfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($imageInfo, $_FILES['image']['tmp_name']);
            finfo_close($imageInfo);
            if (!in_array($mimeType, $allowedTypes, true)) {
                $error = 'Only JPG, PNG, or WEBP images are allowed.';
            } else {
                $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $filename = uniqid('product_', true) . '.' . $extension;
                $target = '../uploads/product-images/' . $filename;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                    $imagePath = 'uploads/product-images/' . $filename;
                } else {
                    $error = 'Unable to save image file.';
                }
            }
        }
    }

    if ($error === '') {
        $stmt = $pdo->prepare('UPDATE products SET name = :name, description = :description, price = :price, image = :image, wattage = :wattage, category = :category, stock = :stock WHERE product_id = :product_id');
        $stmt->execute([
            'name' => $name,
            'description' => $description,
            'price' => $price,
            'image' => $imagePath,
            'wattage' => $wattage,
            'category' => $category,
            'stock' => $stock,
            'product_id' => $productId,
        ]);
        header('Location: products.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Edit Product - Admin | Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Admin Panel</h2>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="customers.php">Customers</a>
        <a href="requests.php">Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Edit Product</h1>
      <?php if ($error): ?>
        <div class="alert alert-error"><?php echo escape($error); ?></div>
      <?php endif; ?>
      <form action="?id=<?php echo escape($productId); ?>" method="POST" enctype="multipart/form-data" class="admin-form">
        <label>Name</label>
        <input type="text" name="name" value="<?php echo escape($product['name']); ?>" required />
        <label>Description</label>
        <textarea name="description" rows="4" required><?php echo escape($product['description']); ?></textarea>
        <div class="form-row">
          <label>Price (PKR)</label>
          <input type="text" name="price" value="<?php echo escape($product['price']); ?>" placeholder="Enter price in PKR" required />
          <label>Wattage</label>
          <input type="text" name="wattage" value="<?php echo escape($product['wattage']); ?>" required />
        </div>
        <div class="form-row">
          <label>Category</label>
          <select name="category" required>
            <option value="Panels" <?php echo $product['category'] === 'Panels' ? 'selected' : ''; ?>>Panels</option>
            <option value="Batteries" <?php echo $product['category'] === 'Batteries' ? 'selected' : ''; ?>>Batteries</option>
            <option value="Inverters" <?php echo $product['category'] === 'Inverters' ? 'selected' : ''; ?>>Inverters</option>
          </select>
          <label>Stock</label>
          <input type="number" name="stock" min="0" value="<?php echo escape($product['stock']); ?>" required />
        </div>
        <label>Product Image</label>
        <input type="file" name="image" accept="image/png,image/jpeg,image/webp" />
        <button type="submit" class="btn btn-primary">Update Product</button>
      </form>
    </main>
  </div>
</body>
</html>
