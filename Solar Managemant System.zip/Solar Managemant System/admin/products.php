<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();

$stmt = $pdo->query('SELECT * FROM products ORDER BY created_at DESC');
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Products - Admin | Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Admin Panel</h2>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php" class="active">Products</a>
        <a href="customers.php">Customers</a>
        <a href="requests.php">Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Manage Products</h1>
      <a href="add-product.php" class="btn btn-primary">Add New Product</a>
      <div class="table-wrap">
        <table class="table" style="margin-top: 1rem;">
          <thead>
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Price (PKR)</th>
              <th>Wattage</th>
              <th>Category</th>
              <th>Stock</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products as $product): ?>
              <tr>
                <td><img src="../<?php echo escape($product['image']); ?>" alt="<?php echo escape($product['name']); ?>" /></td>
                <td><?php echo escape($product['name']); ?></td>
                <td>PKR <?php echo escape(number_format($product['price'], 2)); ?></td>
                <td><?php echo escape($product['wattage']); ?></td>
                <td><?php echo escape($product['category']); ?></td>
                <td><?php echo escape($product['stock']); ?></td>
                <td>
                  <a href="edit-product.php?id=<?php echo escape($product['product_id']); ?>" class="btn btn-secondary">Edit</a>
                  <a href="delete-product.php?id=<?php echo escape($product['product_id']); ?>" class="btn btn-secondary" onclick="return confirm('Delete this product?');">Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($products)): ?>
              <tr><td colspan="7">No products available. Add a new product to begin.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>
