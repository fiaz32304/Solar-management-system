<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireAdmin();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $wattage = trim($_POST['wattage'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $stock = intval($_POST['stock'] ?? 0);

    if ($name === '' || $description === '' || $price === '' || $wattage === '' || $category === '') {
        $error = 'Please complete all product fields.';
    } elseif (!is_numeric($price) || floatval($price) < 0) {
        $error = 'Enter a valid product price.';
    } else {
        $imagePath = 'assets/images/default-product.svg';

        if (!empty($_FILES['image']['name'])) {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
            $imageInfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($imageInfo, $_FILES['image']['tmp_name']);
            finfo_close($imageInfo);
            if (!in_array($mimeType, $allowedTypes, true)) {
                $error = 'Only JPG, PNG, or WEBP images are allowed.';
            } else {
                $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $filename = uniqid('product_', true) . '.' . $extension;
                $target = '../uploads/product-images/' . $filename;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                    $imagePath = 'uploads/product-images/' . $filename;
                } else {
                    $error = 'Unable to save product image.';
                }
            }
        }
    }

    if ($error === '') {
        $stmt = $pdo->prepare('INSERT INTO products (name, description, price, image, wattage, category, stock) VALUES (:name, :description, :price, :image, :wattage, :category, :stock)');
        $stmt->execute([
            'name' => $name,
            'description' => $description,
            'price' => $price,
            'image' => $imagePath,
            'wattage' => $wattage,
            'category' => $category,
            'stock' => $stock,
        ]);
        header('Location: products.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Add Product - Admin | Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Admin Panel</h2>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="customers.php">Customers</a>
        <a href="requests.php">Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Add New Product</h1>
      <?php if ($error): ?>
        <div class="alert alert-error"><?php echo escape($error); ?></div>
      <?php endif; ?>
      <form action="" method="POST" enctype="multipart/form-data" class="admin-form">
        <label>Name</label>
        <input type="text" name="name" required />
        <label>Description</label>
        <textarea name="description" rows="4" required></textarea>
        <div class="form-row">
          <label>Price (PKR)</label>
          <input type="text" name="price" placeholder="Enter price in PKR" required />
          <label>Wattage</label>
          <input type="text" name="wattage" required />
        </div>
        <div class="form-row">
          <label>Category</label>
          <select name="category" required>
            <option value="">Select category</option>
            <option value="Panels">Panels</option>
            <option value="Batteries">Batteries</option>
            <option value="Inverters">Inverters</option>
          </select>
          <label>Stock</label>
          <input type="number" name="stock" min="0" value="0" required />
        </div>
        <label>Product Image</label>
        <input type="file" name="image" accept="image/png,image/jpeg,image/webp" />
        <button type="submit" class="btn btn-primary">Save Product</button>
      </form>
    </main>
  </div>
</body>
</html>
