<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Email and password are required.';
    } else {
        $stmt = $pdo->prepare('SELECT admin_id, password FROM admin WHERE username = :username');
        $stmt->execute(['username' => $username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_username'] = $username;
            header('Location: dashboard.php');
            exit;
        }
        $error = 'Invalid admin credentials.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login - Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <main class="auth-page container">
    <div class="auth-card">
      <h1>Admin Login</h1>
      <?php if ($error): ?>
        <div class="alert alert-error"><?php echo escape($error); ?></div>
      <?php endif; ?>
      <form action="" method="POST">
        <label>Email</label>
        <input type="email" name="username" required />
        <label>Password</label>
        <input type="password" name="password" required minlength="4" />
        <button type="submit" class="btn btn-primary">Login</button>
      </form>
    </div>
  </main>
</body>
</html>
