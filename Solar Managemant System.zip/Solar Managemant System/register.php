<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register - Solar Management</title>
    <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
    <main class="auth-page container">
        <div class="auth-card">
            <h1>Create Account</h1>
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($_GET['error']); ?></div>
            <?php endif; ?>
            <form id="registerForm" action="auth/register.php" method="POST" novalidate>
                <label>Full Name</label>
                <input type="text" name="full_name" required />
                <label>Email</label>
                <input type="email" name="email" required />
                <label>Password</label>
                <input type="password" name="password" required minlength="6" />
                <span class="help-text">Use at least 6 characters.</span>
                <label>Phone</label>
                <input type="text" name="phone" required />
                <label>Address</label>
                <textarea name="address" rows="3" required></textarea>
                <button type="submit" class="btn btn-primary">Register</button>
            </form>
            <p class="helper-text">Already registered? <a href="login.php">Login here</a></p>
            <p class="helper-text">Admin user? <a href="admin/index.php">Login here</a></p>
        </div>
    </main>
    <script src="assets/js/script.js"></script>
</body>
</html>
