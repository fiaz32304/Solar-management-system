<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireUser();

$productId = intval($_GET['id'] ?? 0);
if ($productId <= 0) {
    header('Location: products.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM products WHERE product_id = :product_id');
$stmt->execute(['product_id' => $productId]);
$product = $stmt->fetch();
if (!$product) {
    header('Location: products.php');
    exit;
}

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT request_id, status FROM requests WHERE user_id = :user_id AND product_id = :product_id');
$stmt->execute(['user_id' => $userId, 'product_id' => $productId]);
$request = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo escape($product['name']); ?> - Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Customer Menu</h2>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Browse Products</a>
        <a href="requests.php">My Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <article class="product-card">
        <img src="../<?php echo escape($product['image']); ?>" alt="<?php echo escape($product['name']); ?>" />
        <div class="product-body">
          <h1><?php echo escape($product['name']); ?></h1>
          <p class="help-text"><?php echo escape($product['category']); ?> • <?php echo escape($product['wattage']); ?></p>
          <p><?php echo escape($product['description']); ?></p>
          <div class="product-meta">
            <span>PKR <?php echo escape(number_format($product['price'], 2)); ?></span>
            <span class="badge"><?php echo escape($product['stock'] > 0 ? 'In stock' : 'Out of stock'); ?></span>
          </div>
          <?php if ($request): ?>
            <p class="help-text">You already requested this product. Status: <strong><?php echo escape($request['status']); ?></strong></p>
          <?php else: ?>
            <form action="request.php" method="POST" class="admin-form">
              <input type="hidden" name="product_id" value="<?php echo escape($product['product_id']); ?>" />
              <button type="submit" class="btn btn-primary" <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>Submit Installation Request</button>
            </form>
          <?php endif; ?>
        </div>
      </article>
    </main>
  </div>
</body>
</html>
