<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireUser();

$stmt = $pdo->query('SELECT * FROM products ORDER BY created_at DESC');
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Products - Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Customer Menu</h2>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php" class="active">Browse Products</a>
        <a href="requests.php">My Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Solar Products</h1>
      <div class="product-grid">
        <?php foreach ($products as $product): ?>
          <article class="product-card">
            <img src="../<?php echo escape($product['image']); ?>" alt="<?php echo escape($product['name']); ?>" />
            <div class="product-body">
              <h3><?php echo escape($product['name']); ?></h3>
              <p><?php echo escape(substr($product['description'], 0, 110)); ?>...</p>
              <div class="product-meta">
                <span>PKR <?php echo escape(number_format($product['price'], 2)); ?></span>
                <a href="product-details.php?id=<?php echo escape($product['product_id']); ?>" class="btn btn-secondary">View</a>
              </div>
              <p class="help-text"><?php echo escape($product['wattage']); ?> • <?php echo escape($product['category']); ?></p>
            </div>
          </article>
        <?php endforeach; ?>
        <?php if (empty($products)): ?>
          <p>No products available yet.</p>
        <?php endif; ?>
      </div>
    </main>
  </div>
</body>
</html>
