<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireUser();

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT COUNT(*) AS total_requests FROM requests WHERE user_id = :user_id');
$stmt->execute(['user_id' => $userId]);
$totalRequests = $stmt->fetch()['total_requests'];

$stmt = $pdo->query('SELECT COUNT(*) AS total_products FROM products');
$totalProducts = $stmt->fetch()['total_products'];

$stmt = $pdo->prepare('SELECT status, COUNT(*) AS count FROM requests WHERE user_id = :user_id GROUP BY status');
$stmt->execute(['user_id' => $userId]);
$statusCounts = $stmt->fetchAll();
$statusMap = ['Pending' => 0, 'Approved' => 0, 'Rejected' => 0];
foreach ($statusCounts as $row) {
    $statusMap[$row['status']] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User Dashboard - Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Welcome, <?php echo escape($_SESSION['user_name']); ?></h2>
      <nav>
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="products.php">Browse Products</a>
        <a href="requests.php">My Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Customer Dashboard</h1>
      <div class="cards-grid">
        <div class="card">
          <h3>Total Products</h3>
          <p><?php echo escape($totalProducts); ?></p>
        </div>
        <div class="card">
          <h3>Total Requests</h3>
          <p><?php echo escape($totalRequests); ?></p>
        </div>
        <div class="card">
          <h3>Pending</h3>
          <p><?php echo escape($statusMap['Pending']); ?></p>
        </div>
        <div class="card">
          <h3>Approved</h3>
          <p><?php echo escape($statusMap['Approved']); ?></p>
        </div>
      </div>
      <section style="margin-top: 2rem;">
        <h2>Explore Solar Products</h2>
        <p>Visit the product catalog to request installation for your ideal solar solution.</p>
        <a href="products.php" class="btn btn-primary">Browse Products</a>
      </section>
    </main>
  </div>
</body>
</html>
