<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireUser();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: products.php');
    exit;
}

$productId = intval($_POST['product_id'] ?? 0);
$userId = $_SESSION['user_id'];

if ($productId <= 0) {
    header('Location: products.php');
    exit;
}

$stmt = $pdo->prepare('SELECT product_id, stock FROM products WHERE product_id = :product_id');
$stmt->execute(['product_id' => $productId]);
$product = $stmt->fetch();

if (!$product || $product['stock'] <= 0) {
    header('Location: product-details.php?id=' . $productId);
    exit;
}

$stmt = $pdo->prepare('SELECT request_id FROM requests WHERE user_id = :user_id AND product_id = :product_id');
$stmt->execute(['user_id' => $userId, 'product_id' => $productId]);
if ($stmt->fetch()) {
    header('Location: product-details.php?id=' . $productId);
    exit;
}

$stmt = $pdo->prepare('INSERT INTO requests (user_id, product_id) VALUES (:user_id, :product_id)');
$stmt->execute(['user_id' => $userId, 'product_id' => $productId]);

header('Location: requests.php');
exit;
