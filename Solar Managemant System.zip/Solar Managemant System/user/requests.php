<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
requireUser();

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT r.*, p.name AS product_name, p.image AS product_image FROM requests r JOIN products p ON r.product_id = p.product_id WHERE r.user_id = :user_id ORDER BY r.request_date DESC');
$stmt->execute(['user_id' => $userId]);
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Requests - Solar Management</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
</head>
<body>
  <div class="dashboard-layout container">
    <aside class="sidebar">
      <h2>Customer Menu</h2>
      <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Browse Products</a>
        <a href="requests.php" class="active">My Requests</a>
        <a href="../auth/logout.php">Logout</a>
      </nav>
    </aside>
    <main class="main-panel">
      <h1>Installation Requests</h1>
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Requested On</th>
              <th>Status</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($requests as $request): ?>
              <tr>
                <td>
                  <div style="display:flex; align-items:center; gap:0.75rem;">
                    <img src="../<?php echo escape($request['product_image']); ?>" alt="<?php echo escape($request['product_name']); ?>" />
                    <span><?php echo escape($request['product_name']); ?></span>
                  </div>
                </td>
                <td><?php echo escape(date('M j, Y', strtotime($request['request_date']))); ?></td>
                <td><span class="status-pill <?php echo getStatusClass($request['status']); ?>"><?php echo escape($request['status']); ?></span></td>
                <td><?php echo escape($request['notes'] ?: '—'); ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($requests)): ?>
              <tr><td colspan="4">You have not submitted any installation requests yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>
